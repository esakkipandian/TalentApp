var perfUrl = {
    'addAddressType': apiUri + 'AddressType',
    'loadAddressType': apiUri + 'AddressType',
    'updateAddressType': apiUri + 'AddressType' + '/UpdateAddressType',
    'deleteAddressType': apiUri + 'AddressType' + '/DeleteAddressType',
    'addCandidateInformation': apiUri + 'CandidateInformation',
    'loadCandidateInformation': apiUri + 'Candidates' + '/GetCandidate',
    'updateCandidateInformation': apiUri + 'CandidateInformation',
    'deleteCandidateInformation': apiUri +'Candidates' +'/DeleteCandidateInformation'
};
