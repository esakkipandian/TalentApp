﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prft.Talent.Domain.Talent
{
   public class University
    {
        public string UniversityCode { get; set; }
        public string UniversityName { get; set; }
        public int Id { get; set; }
    }
}
