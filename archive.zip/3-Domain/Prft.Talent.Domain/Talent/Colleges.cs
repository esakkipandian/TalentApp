﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prft.Talent.Domain.Talent
{
   public class Colleges
    {
        public string Id { get; set; }
        public string CollegeCode { get; set; }
        public string CollegeName { get; set; }
    }
}
